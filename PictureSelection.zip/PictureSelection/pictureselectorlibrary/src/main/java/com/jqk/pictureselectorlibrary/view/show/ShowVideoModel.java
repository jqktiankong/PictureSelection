package com.jqk.pictureselectorlibrary.view.show;

import android.content.Context;
import android.support.annotation.NonNull;

import com.jqk.pictureselectorlibrary.bean.Folder;
import com.jqk.pictureselectorlibrary.util.L;
import com.jqk.pictureselectorlibrary.util.ObservableFactroy;
import com.jqk.pictureselectorlibrary.view.batchSelector.BathSelectorModel;

import java.io.File;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class ShowVideoModel {
    private Observable<String> observable;

    public interface ShowVideoOnCallback {
        void onFail(String fail);
        void onFinish(String path);
    }

    public void trimVideo(File src, String dst, long startMs, long endMs, final ShowVideoOnCallback onCallback) {
        observable = ObservableFactroy.trimVideo(src, dst, startMs, endMs);
        observable.subscribe(new Observer<String>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onComplete() {

            }

            @Override
            public void onError(Throwable e) {
                L.d("e = " + e.toString());
                onCallback.onFail(e.toString());
            }

            @Override
            public void onNext(String path) {
                onCallback.onFinish(path);
            }
        });
    }

    public void onDestroy() {
        if (observable != null) {
            observable.unsubscribeOn(Schedulers.io());
        }
    }
}
