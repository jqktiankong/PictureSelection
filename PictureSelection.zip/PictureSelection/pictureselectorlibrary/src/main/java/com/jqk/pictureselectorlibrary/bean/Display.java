package com.jqk.pictureselectorlibrary.bean;

/**
 * Created by Administrator on 2018/1/3.
 */

public class Display {
    private int viewType;
    private int id;
    private Picture picture;

    public int getViewType() {
        return viewType;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Picture getPicture() {
        return picture;
    }

    public void setPicture(Picture picture) {
        this.picture = picture;
    }
}
