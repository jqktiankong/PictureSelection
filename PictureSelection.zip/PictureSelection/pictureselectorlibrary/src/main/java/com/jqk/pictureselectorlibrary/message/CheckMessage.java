package com.jqk.pictureselectorlibrary.message;

/**
 * Created by Administrator on 2018/4/12 0012.
 */

public class CheckMessage {
    private int position;
    private boolean check;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }
}
