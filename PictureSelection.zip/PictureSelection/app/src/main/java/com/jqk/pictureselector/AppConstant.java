package com.jqk.pictureselector;

/**
 * Created by  on 2017/9/5.
 */

public class AppConstant {
    public static final String TAG = "123456";

    public static final int DURATIONFORFOLDER = 300;

}
